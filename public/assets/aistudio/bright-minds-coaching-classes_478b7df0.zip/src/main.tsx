import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initSecurityHardening } from './utils/security';

// Initialize defensive client-side prototype and tampering protections
initSecurityHardening();

if (typeof window !== 'undefined' && 'scrollRestoration' in window.history) {
  window.history.scrollRestoration = 'manual';
}

createRoot(document.getElementById('root')!).render(<App />);
